<?php
    header('Content-Type: text/html; charset=utf-8');
    include("../connect.php");


    try {
        // Connexion à la base de données
        $conn = pdo_connectDB("127.0.0.1", "3306", "db_projet_tm", "adminProjet", "Pv8gTpwzuBHokz4f");
        $conn->beginTransaction();

        // Protection XSS (et contre les scripts <script>)
        $titre = htmlspecialchars(trim($_POST["titre"]), ENT_QUOTES, 'UTF-8');
        $contenu = htmlspecialchars(trim($_POST["contenu"]), ENT_QUOTES, 'UTF-8');
        $categorie_id = (int) $_POST["categorie_id"];

        // L'utilisateur doit être connecté
        if (!isset($_SESSION["id_utilisateur"])) {
            throw new Exception("Utilisateur non connecté.");
        }

        $id_utilisateur = $_SESSION["id_utilisateur"];

        // Préparation de la requête
        $sql = "INSERT INTO sujet (titre, contenu, categorie_id, utilisateur_id, date_creation) 
                VALUES (:titre, :contenu, :categorie_id, :utilisateur_id, NOW())";
        $statement = $conn->prepare($sql);

        // Liaison des paramètres
        $statement->bindParam(':titre', $titre, PDO::PARAM_STR);
        $statement->bindParam(':contenu', $contenu, PDO::PARAM_STR);
        $statement->bindParam(':categorie_id', $categorie_id, PDO::PARAM_INT);
        $statement->bindParam(':utilisateur_id', $id_utilisateur, PDO::PARAM_INT);

        $statement->execute();

        $conn->commit();

        echo json_encode(["success" => true, "message" => "Sujet publié avec succès."]);
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode(["success" => false, "message" => $e->getMessage()]);
    }
?>
